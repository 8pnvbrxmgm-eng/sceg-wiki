// =====================================================
// SCEG Wiki — Cloudflare Worker Proxy pour OpenAI
// Instructions de déploiement en bas du fichier
// =====================================================

export default {
  async fetch(request, env) {

    // Autoriser les requêtes CORS depuis n'importe quel domaine
    if (request.method === 'OPTIONS') {
      return new Response(null, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'POST, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type',
          'Access-Control-Max-Age': '86400',
        }
      });
    }

    if (request.method !== 'POST') {
      return new Response('Méthode non autorisée', { status: 405 });
    }

    try {
      const body = await request.json();

      // La clé API OpenAI est stockée dans les secrets Cloudflare (pas exposée au public)
      const OPENAI_API_KEY = env.OPENAI_API_KEY;

      if (!OPENAI_API_KEY) {
        return new Response(JSON.stringify({ error: 'Clé API non configurée dans Cloudflare' }), {
          status: 500,
          headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
        });
      }

      // Appel vers OpenAI
      const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${OPENAI_API_KEY}`
        },
        body: JSON.stringify(body)
      });

      const data = await openaiResponse.json();

      return new Response(JSON.stringify(data), {
        status: openaiResponse.status,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        }
      });

    } catch (err) {
      return new Response(JSON.stringify({ error: err.message }), {
        status: 500,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
      });
    }
  }
};

/*
========================================================
  INSTRUCTIONS POUR DÉPLOYER CE WORKER (GRATUIT)
========================================================

ÉTAPE 1 — Créer un compte Cloudflare
  → Allez sur https://cloudflare.com → Sign Up (gratuit)

ÉTAPE 2 — Créer un Worker
  → Dashboard Cloudflare → "Workers & Pages" → "Create"
  → Choisir "Create Worker"
  → Donnez un nom : "sceg-wiki-proxy"
  → Cliquez "Deploy"

ÉTAPE 3 — Coller le code
  → Cliquez "Edit code"
  → Sélectionnez tout le code existant et supprimez-le
  → Collez TOUT le contenu de ce fichier (sans les commentaires /*...*/ du bas)
  → Cliquez "Deploy"

ÉTAPE 4 — Ajouter votre clé API OpenAI comme Secret
  → Dans votre Worker → onglet "Settings" → "Variables and Secrets"
  → Cliquez "Add variable" → Type : "Secret"
  → Nom : OPENAI_API_KEY
  → Valeur : votre clé sk-...
  → Cliquez "Deploy"

ÉTAPE 5 — Récupérer l'URL du Worker
  → L'URL ressemble à : https://sceg-wiki-proxy.VOTRENOM.workers.dev
  → Copiez cette URL

ÉTAPE 6 — Mettre l'URL dans votre site SCEG Wiki
  → Connectez-vous en admin sur le wiki
  → Dans "Actions rapides" → collez l'URL du Worker
  → Cliquez Enregistrer

C'est tout ! Le Worker est gratuit jusqu'à 100,000 requêtes/jour.
========================================================
*/
